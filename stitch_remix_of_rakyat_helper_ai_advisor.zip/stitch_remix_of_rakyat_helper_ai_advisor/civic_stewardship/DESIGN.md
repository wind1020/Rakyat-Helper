---
name: Civic Stewardship
colors:
  surface: '#fdf8fd'
  surface-dim: '#ddd9de'
  surface-bright: '#fdf8fd'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f2f8'
  surface-container: '#f1ecf2'
  surface-container-high: '#ebe7ec'
  surface-container-highest: '#e5e1e7'
  on-surface: '#1c1b1f'
  on-surface-variant: '#444653'
  inverse-surface: '#313034'
  inverse-on-surface: '#f4eff5'
  outline: '#747684'
  outline-variant: '#c4c5d5'
  surface-tint: '#3556c1'
  primary: '#00206e'
  on-primary: '#ffffff'
  primary-container: '#0032a0'
  on-primary-container: '#8ea5ff'
  inverse-primary: '#b7c4ff'
  secondary: '#775a00'
  on-secondary: '#ffffff'
  secondary-container: '#ffc72c'
  on-secondary-container: '#6f5400'
  tertiary: '#262829'
  on-tertiary: '#ffffff'
  tertiary-container: '#3c3e3e'
  on-tertiary-container: '#a8a9a9'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b7c4ff'
  on-primary-fixed: '#001551'
  on-primary-fixed-variant: '#143ca9'
  secondary-fixed: '#ffdf99'
  secondary-fixed-dim: '#f6bf22'
  on-secondary-fixed: '#251a00'
  on-secondary-fixed-variant: '#5a4300'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#fdf8fd'
  on-background: '#1c1b1f'
  surface-variant: '#e5e1e7'
typography:
  display-lg:
    fontFamily: Public Sans
    fontSize: 57px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.25px
  headline-lg:
    fontFamily: Public Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Public Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  title-md:
    fontFamily: Public Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0.15px
  body-lg:
    fontFamily: Public Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.5px
  body-md:
    fontFamily: Public Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.25px
  label-md:
    fontFamily: Public Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.5px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  gutter-sm: 16px
  gutter-md: 24px
  margin-mobile: 16px
  margin-desktop: 64px
  max-width-desktop: 1200px
---

## Brand & Style
The design system is built for the **Malaysian Civic Aid System**, targeting citizens and administrators who require clarity, efficiency, and a sense of institutional reliability. The brand personality is grounded, authoritative, and inclusive, evoking an emotional response of security and civic duty.

The design style is **Corporate / Modern**, leaning heavily into systematic functionalism. It prioritizes high legibility and clear information hierarchy over decorative elements. By utilizing a structured layout and a professional color palette, the system communicates transparency and trust, ensuring that critical aid information is accessible to all demographics without friction.

## Colors
The palette is centered around **Malaysian Blue (#0032A0)**, representing stability and national identity. This primary color is used for key actions and branding elements. **Gold (#FFC72C)** serves as a secondary accent, used sparingly to highlight critical status updates or specialized aid categories.

The color system follows a strict accessibility protocol:
- **Primary actions** utilize the deep Malaysian Blue with white text to ensure a contrast ratio exceeding 7:1.
- **Containers** use a desaturated, lightened version of the primary blue to group related content without overwhelming the visual field.
- **Surface colors** are kept near-white to maintain a "paper-like" administrative feel, emphasizing the official nature of the platform.

## Typography
This design system utilizes **Public Sans**, an institutional typeface designed for accessibility and clarity. The typeface is used across all levels to maintain a neutral, official tone.

- **Headlines** use semi-bold weights to provide clear section breaks.
- **Body text** maintains a generous line height (1.5x) to facilitate reading of complex policy or instructional content.
- **Mobile scaling** is applied to the largest headlines to prevent awkward text wrapping on smaller devices, ensuring that the primary message remains the focus.

## Layout & Spacing
The layout follows a **Fixed Grid** model on desktop to maintain an authoritative, centered appearance, while transitioning to a **Fluid Grid** on mobile devices.

- **Desktop:** A 12-column grid with a 1200px max-width, 24px gutters, and 64px side margins.
- **Tablet:** An 8-column grid with 24px gutters and 32px margins.
- **Mobile:** A 4-column grid with 16px gutters and 16px margins.

Spacing is calculated on an 8px base unit. Vertical rhythm is strictly enforced, with sections separated by 48px or 64px to provide "breathing room" between dense data points.

## Elevation & Depth
Elevation in this design system is communicated through **Tonal Layers** and **Low-Contrast Outlines**.

The design avoids heavy drop shadows to maintain a modern, clean institutional look. Instead:
- **Surface Levels:** The base background is the lightest. Cards and containers use a white background with a subtle 1px border (`#E0E0E0`).
- **Interactive Depth:** On hover, elements may gain a soft, ambient shadow (4px blur, 10% opacity) to indicate clickability.
- **Modals:** Use a significant backdrop blur (8px) to isolate critical user tasks from the background information, focusing the user's attention on the aid application or data entry.

## Shapes
The shape language is **Soft (0.25rem)**. This subtle rounding of corners balances professional rigidity with approachable modernism.

- **Buttons & Inputs:** Use the standard 4px (0.25rem) radius.
- **Cards & Banners:** Use the `rounded-lg` (8px) radius to softly enclose larger blocks of content.
- **System Icons:** Should follow a "filled" style with slightly rounded terminals to match the UI's geometric yet accessible feel.

## Components
Consistent implementation of components is vital for user trust:

- **Buttons:** The primary button uses the Malaysian Blue background with white text. Secondary buttons use a primary-colored outline.
- **Input Fields:** Use a standard height of 48px with a 1px border. The label should always be visible above the field (not floating) for maximum accessibility.
- **Cards:** Used to summarize aid programs. They must include a `title-md` header and a clear "Apply" or "View Details" call-to-action button.
- **Chips:** Used for status indicators (e.g., "Pending," "Approved"). Use high-contrast colors (e.g., green for approved, Malaysian Blue for active).
- **Data Tables:** Crucial for the administrative side of the system; rows should have a hover state and utilize `body-md` for high information density without sacrificing legibility.